"""
Script d'entraînement du modèle brain.tflite
Usage : pip install tensorflow numpy && python train_brain.py
"""

import numpy as np
import tensorflow as tf
from tensorflow import keras

print("🧠 Entraînement du modèle Personal AI Agent...")

# ============================================================
# DONNÉES D'ENTRAÎNEMENT
# Features : [usage_score, heure_normalisée, niveau_batterie]
# Label    : 1 = lancer tâche, 0 = attendre
# ============================================================
X_train = np.array([
    # usage,  heure,  batterie  → action
    [0.8,    0.2,    0.9],    # Usage élevé matin, batterie pleine → lancer
    [0.9,    0.1,    0.8],    # Très actif tôt, batterie bonne → lancer
    [0.7,    0.3,    0.7],    # Actif en matinée → lancer
    [0.6,    0.4,    0.6],    # Usage moyen → lancer
    [0.1,    0.8,    0.3],    # Faible usage soir, batterie basse → attendre
    [0.2,    0.9,    0.2],    # Inactif nuit, batterie très basse → attendre
    [0.1,    1.0,    0.1],    # Inactif tard, batterie critique → attendre
    [0.3,    0.7,    0.4],    # Peu actif soir → attendre
    [0.5,    0.5,    0.5],    # Neutre → lancer (légère préférence)
    [0.4,    0.6,    0.5],    # Légèrement passif → attendre
], dtype=np.float32)

y_train = np.array(
    [1, 1, 1, 1, 0, 0, 0, 0, 1, 0],
    dtype=np.float32
)

# ============================================================
# MODÈLE
# ============================================================
model = keras.Sequential([
    keras.layers.Dense(16, activation='relu', input_shape=(3,), name='input_layer'),
    keras.layers.Dropout(0.2),
    keras.layers.Dense(8, activation='relu', name='hidden_layer'),
    keras.layers.Dense(1, activation='sigmoid', name='output_layer')
])

model.compile(
    optimizer=keras.optimizers.Adam(learning_rate=0.001),
    loss='binary_crossentropy',
    metrics=['accuracy']
)

model.summary()

# ============================================================
# ENTRAÎNEMENT
# ============================================================
history = model.fit(
    X_train, y_train,
    epochs=100,
    batch_size=4,
    validation_split=0.2,
    verbose=1
)

final_accuracy = history.history['accuracy'][-1]
print(f"\n✅ Accuracy finale : {final_accuracy:.2%}")

# ============================================================
# CONVERSION EN TFLITE (avec quantization)
# ============================================================
converter = tf.lite.TFLiteConverter.from_keras_model(model)
converter.optimizations = [tf.lite.Optimize.DEFAULT]  # Quantization légère int8

tflite_model = converter.convert()

# ============================================================
# SAUVEGARDE
# ============================================================
output_path = "brain.tflite"
with open(output_path, "wb") as f:
    f.write(tflite_model)

size_kb = len(tflite_model) / 1024
print(f"✅ brain.tflite généré : {size_kb:.1f} KB")
print(f"📁 Copie ce fichier dans : app/src/main/assets/brain.tflite")

# ============================================================
# TEST RAPIDE DU MODÈLE
# ============================================================
print("\n🧪 Test du modèle TFLite...")
interpreter = tf.lite.Interpreter(model_content=tflite_model)
interpreter.allocate_tensors()

input_details  = interpreter.get_input_details()
output_details = interpreter.get_output_details()

test_cases = [
    ([0.9, 0.1, 0.9], "Usage élevé matin"),
    ([0.1, 0.9, 0.2], "Usage faible soir batterie basse"),
    ([0.5, 0.5, 0.5], "Cas neutre"),
]

for features, label in test_cases:
    input_data = np.array([features], dtype=np.float32)
    interpreter.set_tensor(input_details[0]['index'], input_data)
    interpreter.invoke()
    output = interpreter.get_tensor(output_details[0]['index'])[0][0]
    decision = "🟢 LANCER" if output > 0.5 else "🔴 ATTENDRE"
    print(f"  {label:40s} → {output:.3f} {decision}")

print("\n🚀 Tout est prêt !")
