package com.yourname.aiagent

import android.content.Context
import android.util.Log
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

class BrainInterpreter(context: Context) {

    companion object {
        const val TAG = "AI_AGENT"
        const val MODEL_FILE = "brain.tflite"
    }

    private val interpreter: Interpreter

    init {
        val options = Interpreter.Options().apply {
            numThreads = 2
            useNNAPI = true
        }
        val model = loadModelFile(context)
        interpreter = Interpreter(model, options)
        Log.d(TAG, "✅ BrainInterpreter initialisé")
    }

    private fun loadModelFile(context: Context): MappedByteBuffer {
        val fd = context.assets.openFd(MODEL_FILE)
        val stream = FileInputStream(fd.fileDescriptor)
        return stream.channel.map(
            FileChannel.MapMode.READ_ONLY,
            fd.startOffset,
            fd.declaredLength
        )
    }

    fun predict(features: FloatArray): Float {
        val input = Array(1) { features }
        val output = Array(1) { FloatArray(1) }
        interpreter.run(input, output)
        return output[0][0]
    }

    fun close() {
        interpreter.close()
        Log.d(TAG, "🔒 BrainInterpreter fermé")
    }
}
