package com.yourname.aiagent

import android.content.Context
import android.os.BatteryManager
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.text.SimpleDateFormat
import java.util.*

class AutomationWorker(
    private val ctx: Context,
    params: WorkerParameters
) : CoroutineWorker(ctx, params) {

    companion object {
        const val TAG = "AI_AGENT"
    }

    override suspend fun doWork(): Result {
        Log.d(TAG, "🚀 Worker démarré : ${Date()}")

        val brain = BrainInterpreter(ctx)
        return try {
            val features = floatArrayOf(
                getUsageScore(),
                getHour(),
                getBatteryLevel()
            )

            Log.d(TAG, "📊 Features : ${features.toList()}")

            val prediction = brain.predict(features)
            Log.d(TAG, "🧠 Prédiction : $prediction")

            // Sauvegarde pour le Dashboard
            val prefs = ctx.getSharedPreferences("AI_AGENT", Context.MODE_PRIVATE)
            prefs.edit()
                .putFloat("last_prediction", prediction)
                .putString(
                    "last_run",
                    SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())
                )
                .apply()

            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "❌ Erreur Worker : ${e.message}", e)
            Result.retry()
        } finally {
            brain.close()
        }
    }

    private fun getBatteryLevel(): Float {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) / 100f
    }

    private fun getHour(): Float =
        Calendar.getInstance().get(Calendar.HOUR_OF_DAY) / 23f

    private fun getUsageScore(): Float {
        // Placeholder — à enrichir avec UsageStatsManager
        return 0.5f
    }
}
