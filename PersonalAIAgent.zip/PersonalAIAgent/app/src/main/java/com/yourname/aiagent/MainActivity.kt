package com.yourname.aiagent

import android.app.AppOpsManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.work.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    companion object {
        const val TAG = "AI_AGENT"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvPermission = findViewById<TextView>(R.id.tvPermission)
        val btnDashboard = findViewById<Button>(R.id.btnDashboard)
        val btnTestNow = findViewById<Button>(R.id.btnTestNow)

        // Vérifier permission UsageStats
        if (!hasUsageStatsPermission()) {
            tvPermission.text = "⚠️ Permission requise : Accès utilisation apps"
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        } else {
            tvPermission.text = "✅ Permissions OK"
        }

        // Planifier le Worker périodique
        scheduleAIWorker()

        // Bouton Dashboard
        btnDashboard.setOnClickListener {
            startActivity(Intent(this, DashboardActivity::class.java))
        }

        // Bouton Test immédiat
        btnTestNow.setOnClickListener {
            testWorkerNow()
        }
    }

    private fun hasUsageStatsPermission(): Boolean {
        val appOps = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun scheduleAIWorker() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .setRequiresBatteryNotLow(true)
            .build()

        val request = PeriodicWorkRequestBuilder<AutomationWorker>(
            15, TimeUnit.MINUTES,
            5, TimeUnit.MINUTES
        )
            .setConstraints(constraints)
            .setBackoffCriteria(
                BackoffPolicy.EXPONENTIAL,
                WorkRequest.MIN_BACKOFF_MILLIS,
                TimeUnit.MILLISECONDS
            )
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "AI_AGENT",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )

        Log.d(TAG, "✅ Worker planifié toutes les 15 minutes")
    }

    private fun testWorkerNow() {
        val request = OneTimeWorkRequestBuilder<AutomationWorker>().build()
        WorkManager.getInstance(this).enqueue(request)
        Log.d(TAG, "🚀 Worker forcé manuellement")
    }
}
