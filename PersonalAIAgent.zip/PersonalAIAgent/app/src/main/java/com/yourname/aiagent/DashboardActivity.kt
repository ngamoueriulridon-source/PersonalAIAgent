package com.yourname.aiagent

import android.content.Context
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.work.WorkInfo
import androidx.work.WorkManager
import java.util.Locale

class DashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        val tvStatus      = findViewById<TextView>(R.id.tvStatus)
        val tvLastRun     = findViewById<TextView>(R.id.tvLastRun)
        val tvPrediction  = findViewById<TextView>(R.id.tvPrediction)
        val tvBattery     = findViewById<TextView>(R.id.tvBattery)

        // Données SharedPreferences
        val prefs = getSharedPreferences("AI_AGENT", Context.MODE_PRIVATE)
        val lastRun = prefs.getString("last_run", "Jamais")
        val lastPrediction = prefs.getFloat("last_prediction", -1f)

        tvLastRun.text = "🕐 Dernière exécution : $lastRun"

        tvPrediction.text = when {
            lastPrediction < 0 -> "🔘 Aucune prédiction encore"
            lastPrediction > 0.5f ->
                "🟢 Action recommandée (${String.format(Locale.getDefault(), "%.0f", lastPrediction * 100)}%)"
            else ->
                "🔴 Attente conseillée (${String.format(Locale.getDefault(), "%.0f", lastPrediction * 100)}%)"
        }

        // État du Worker
        WorkManager.getInstance(this)
            .getWorkInfosForUniqueWorkLiveData("AI_AGENT")
            .observe(this) { workInfos ->
                val active = workInfos.any {
                    it.state == WorkInfo.State.ENQUEUED || it.state == WorkInfo.State.RUNNING
                }
                tvStatus.text = if (active) "✅ Agent actif" else "❌ Agent inactif"
            }

        // Batterie
        val bm = getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
        val batteryLevel = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
        tvBattery.text = "🔋 Batterie : $batteryLevel%"
    }
}
