# 🤖 Personal AI Agent — Android

Agent IA embarqué sur Android avec TensorFlow Lite, WorkManager, chiffrement AES/GCM.

---

## 📁 Structure du projet

```
PersonalAIAgent/
├── app/src/main/
│   ├── java/com/yourname/aiagent/
│   │   ├── MainActivity.kt
│   │   ├── DashboardActivity.kt
│   │   ├── AutomationWorker.kt
│   │   ├── BrainInterpreter.kt
│   │   └── SecureStorage.kt
│   ├── res/
│   │   ├── layout/activity_main.xml
│   │   ├── layout/activity_dashboard.xml
│   │   ├── values/themes.xml
│   │   └── xml/network_security_config.xml
│   ├── assets/
│   │   └── brain.tflite  ← ⚠️ À ajouter manuellement !
│   └── AndroidManifest.xml
├── .github/workflows/build_apk.yml
├── build.gradle
├── app/build.gradle
└── settings.gradle
```

---

## 🚀 Option A — Build local avec Android Studio

1. Ouvre le dossier dans Android Studio
2. Ajoute ton fichier `brain.tflite` dans `app/src/main/assets/`
3. Sync Gradle → `File > Sync Project with Gradle Files`
4. Build → `Build > Build Bundle(s) / APK(s) > Build APK(s)`
5. L'APK est dans : `app/build/outputs/apk/debug/app-debug.apk`

---

## ☁️ Option B — Build cloud avec GitHub Actions (0 install)

### Étapes :

1. **Crée un repo GitHub** (public ou privé)
2. **Push ce projet** :
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/TON_USERNAME/PersonalAIAgent.git
   git push -u origin main
   ```
3. **Va dans l'onglet Actions** de ton repo GitHub
4. Le workflow se lance automatiquement
5. Une fois terminé → **Actions > ton build > Artifacts** → télécharge `app-debug-apk`

### Pour l'APK signé (release) :

Ajoute ces secrets dans `Settings > Secrets and variables > Actions` :

| Secret | Valeur |
|---|---|
| `KEYSTORE_BASE64` | `base64 -w 0 keystore.jks` |
| `KEY_ALIAS` | Ton alias de clé |
| `KEY_PASSWORD` | Mot de passe de la clé |
| `STORE_PASSWORD` | Mot de passe du keystore |

---

## 📱 Permissions requises sur le téléphone

Après installation, va dans :
```
Paramètres > Sécurité > Accès à l'utilisation des apps > AI Agent → Activer
```

---

## 🧠 Ajouter ton modèle IA

Génère `brain.tflite` avec le script Python fourni :
```bash
pip install tensorflow numpy
python train_brain.py
```
Puis copie `brain.tflite` dans `app/src/main/assets/`.

---

## 🔐 Sécurité

- Chiffrement AES/GCM via Android Keystore
- HTTPS uniquement (network_security_config)
- Aucune donnée envoyée à l'extérieur
- `allowBackup="false"`
